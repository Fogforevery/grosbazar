#!/bin/sh

if [ ! -f "node_modules/.bin/serve" ]; then
    echo "Installing 'serve' locally..."
    npm install serve
fi

PID_FILE="serve_pids.txt"

DIR1="itemDist"
DIR2="shopDist"

PORT1=3010
PORT2=3011

if [ -f $PID_FILE ]; then
    rm $PID_FILE
fi

SERVE="./node_modules/.bin/serve"

$SERVE -s $DIR1 -l $PORT1 -L &
PID1=$!
echo $PID1 >> $PID_FILE
echo "Server launched for $DIR1 on http://localhost:$PORT1 (PID: $PID1)"

$SERVE -s $DIR2 -l $PORT2 -L &
PID2=$!
echo $PID2 >> $PID_FILE
echo "Server launched for $DIR2 on http://localhost:$PORT2 (PID: $PID2)"

echo "The PIDs for the servers are saved in $PID_FILE."
echo "You can use './stop.sh' to stop the servers or 'kill $PID1 $PID2'"

